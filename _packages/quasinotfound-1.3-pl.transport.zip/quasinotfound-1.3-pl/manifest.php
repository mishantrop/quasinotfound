<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2ca7e423ae422e1a0e2cb0f5650f220c',
      'native_key' => 'quasinotfound',
      'filename' => 'modNamespace/c79aeabf6338e27de3ba219d1ae4096e.vehicle',
      'namespace' => 'quasinotfound',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'f9448d28b7602e981bf4925da156d43c',
      'native_key' => 11,
      'filename' => 'modPlugin/8b9e57da82e02a78334b1247df06fc56.vehicle',
      'namespace' => 'quasinotfound',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7119ce69d41e6368b24001aa69db0d75',
      'native_key' => 1,
      'filename' => 'modCategory/aba45054dab8fb4a01136de21345d077.vehicle',
      'namespace' => 'quasinotfound',
    ),
  ),
);